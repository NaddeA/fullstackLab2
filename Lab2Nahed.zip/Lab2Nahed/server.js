require('dotenv').config();
const express = require('express');
const path = require('path');
const app = express();
const mongoose = require('mongoose');
const port = process.env.PORT || 3000; 

module.exports = app;


mongoose.connect(process.env.MONGODB_URI, { 
  useNewUrlParser: true, 
  useUnifiedTopology: true, 
})

.then(() => console.log('MongoDB connected...'))
.catch(err => console.log(err));

const Schema = mongoose.Schema;

const employeeSchema = new Schema({
  employee_id: { type: String, required: true, unique: true },
  full_name: { type: String, required: true },
  email: { type: String, required: true },
  hashed_password: { type: String } 
});

const projectSchema = new Schema({
  project_code: { type: String, required: true, unique: true },
  project_name: { type: String, required: true },
  project_description: { type: String, required: true }
});

const projectAssignmentSchema = new Schema({
  employee_id: { type: String, required: true, ref: 'Employee' },
  project_code: { type: String, required: true, ref: 'Project' },
  start_date: { type: Date, required: true }
});

const Employee = mongoose.model('Employee', employeeSchema);
const Project = mongoose.model('Project', projectSchema);
const ProjectAssignment = mongoose.model('ProjectAssignment', projectAssignmentSchema);


// Check if connected or not
mongoose.connection.on('connected', () => {
  console.log('Connected to MongoDB');
});

module.exports = {
  Employee,
  Project,
  ProjectAssignment
};


mongoose.connection.on('error', (error) => {
  console.error('MongoDB connection error:', error);
});

// Define Mongoose schema and model
const ItemSchema = new mongoose.Schema({

});
const Item = mongoose.model('Item', ItemSchema);

// parse JSON
app.use(express.json());

// API routes for different collections
// For employees
app.get('/api/employees', async (req, res) => {
  try {
    const employees = await Employee.find();
    res.json(employees);
  } catch (error) {
    res.status(500).send(error);
  }
});

// For projects
app.get('/api/projects', async (req, res) => {
  try {
    const projects = await Project.find();
    res.json(projects);
  } catch (error) {
    res.status(500).send(error);
  }
});

// For project assignments
app.get('/api/project-assignments', async (req, res) => {
  try {
    const projectAssignments = await ProjectAssignment.find();
    res.json(projectAssignments);
  } catch (error) {
    res.status(500).send(error);
  }
});

// POST endpoint for Employee
app.post('/api/employees', async (req, res) => {
  try {
    const newEmployee = new Employee(req.body);
    await newEmployee.save();
    res.status(201).json(newEmployee);
  } catch (error) {
    if (error.code === 11000) {  // MongoDB duplicate key error
      res.status(409).send('Employee ID must be unique');
    } else {
      res.status(500).send('Internal server error');
    }
  }
});


app.post('/api/projects', async (req, res) => {
  try {
    const newProject = new Project(req.body);
    await newProject.save();
    res.status(201).json(newProject);
  } catch (error) {
    if (error.code === 11000) {
      res.status(409).send('Project code must be unique');
    } else {
      res.status(500).send('Internal server error');
    }
  }
});


// Serve the static files from the React app
app.use(express.static(path.join(__dirname, 'dist')));



app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});