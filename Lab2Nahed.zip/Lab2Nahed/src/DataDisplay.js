import React, { useState, useEffect } from 'react';

function DataDisplay() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {

    const fetchEmployees = async () => {
      setLoading(true); // Start loading before fetching data
      try {
        const response = await fetch('/api/employees');
        const data = await response.json();
        setEmployees(data);
        setLoading(false);  // Stop loading after data is fetched
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);  // Stop loading if an error occurs
      }
    };

    fetchEmployees();
  }, []);

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <table>
      <thead>
        <tr>
          <th>Employee ID</th>
          <th>Full Name</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
        {employees.map(employee => (
          <tr key={employee.employee_id}>
            <td>{employee.employee_id}</td>
            <td>{employee.full_name}</td>
            <td>{employee.email}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default DataDisplay;
