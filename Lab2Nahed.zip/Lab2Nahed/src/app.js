import React from 'react';
import '../public/styles.css'
import DataDisplay from './DataDisplay';

function App() {
  return (
    <div>
      <h1>Welcome to Our Application</h1>
      <DataDisplay /> {/* This is where DataDisplay component is inserted */}
    </div>
  );
}

export default App;

